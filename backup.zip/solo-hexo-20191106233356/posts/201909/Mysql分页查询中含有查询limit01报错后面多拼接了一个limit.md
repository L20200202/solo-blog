title: Mysql分页查询中含有查询limit 0,1 报错，后面多拼接了一个 limit
date: '2019-09-19 17:40:40'
updated: '2019-10-10 23:29:59'
tags: [mysql]
permalink: /articles/2019/09/19/1568886040741.html
---
![](https://img.hacpai.com/bing/20171210.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## Mysql查询limit 0,1 报错，后面多拼接了一个 limit
Q. 1.某一个查询方法包含limit 0,1
```mysql
select * from userinfo where csymbol = 'MuLang' limit 0,1
```
2.使用此方法的时候，在一个分页查询中使用
然后报错日志输出如下：

![image.png](https://img.hacpai.com/file/2019/09/image-01941c22.png)

A.将此查询放到分页查询之外，之前或者之后，组织好信息在进行分页查询

